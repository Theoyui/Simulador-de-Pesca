<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "jailson"; // nome do banco

// Criar conexão
$conn = new mysqli($servername, $username, $password, $database);

// Verificar conexão
if ($conn->connect_error) {
  die("Erro de conexão: " . $conn->connect_error);
}

// Pegar dados do formulário
$nome = $_POST['nomecontato'];
$email = $_POST['emailcontato'];
$telefone = $_POST['telefonecontato'];
$assunto = $_POST['assuntocontato'];
$mensagem = $_POST['mensagemcontato'];

// Inserir no banco
$sql = "INSERT INTO contatos (nomecontato, emailcontato, telefonecontato, assuntocontato, mensagemcontato)
        VALUES ('$nome', '$email', '$telefone', '$assunto', '$mensagem')";

if ($conn->query($sql) === TRUE) {
  echo "Contato enviado com sucesso!";
} else {
  echo "Erro: " . $conn->error;
}

$conn->close();
?>