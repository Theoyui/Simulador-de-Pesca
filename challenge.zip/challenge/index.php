<div class="area-card">
    <div class="area-icon">📚</div>
    <h3>Linguagens</h3>
    <p>Projetos envolvendo produção textual, análise literária, comunicação digital e expressão artística com uso de tecnologias web e multimídia. Desenvolvimento de blogs, plataformas de conteúdo e ferramentas interativas para o estudo da língua portuguesa e literatura.</p>
</div>

<div class="area-card">
    <div class="area-icon">🌍</div>
    <h3>Ciências Humanas</h3>
    <p>Integração de História, Geografia, Sociologia e Filosofia com T.I., desenvolvendo mapas interativos, análises de dados sociais, plataformas educativas e ferramentas de visualização de dados demográficos e históricos com impacto social.</p>
</div>

<div class="area-card">
    <div class="area-icon">🔬</div>
    <h3>Ciências da Natureza</h3>
    <p>Aplicações de Física, Química, Biologia e Matemática através de simuladores científicos, calculadoras especializadas, sistemas de análise de dados experimentais e visualizações interativas de fenômenos naturais e processos químicos.</p>
</div>

<div class="area-card">
    <div class="area-icon">🔒</div>
    <h3>Cibersegurança</h3>
    <p>Estudos em segurança da informação, criptografia, autenticação segura, detecção de vulnerabilidades, proteção de sistemas e dados. Implementação de firewalls, sistemas de autenticação multifator e ferramentas de análise de segurança.</p>
</div>

<div class="area-card">
    <div class="area-icon">⛓️</div>
    <h3>Blockchain</h3>
    <p>Exploração de tecnologia blockchain, criptomoedas, contratos inteligentes e aplicações descentralizadas com implementações práticas. Desenvolvimento de blockchains educacionais, sistemas de votação e plataformas de tokenização.</p>
</div>

<div class="area-card">
    <div class="area-icon">🤖</div>
    <h3>Automação e Robótica</h3>
    <p>Projetos com Arduino, Raspberry Pi, IoT, sensores e atuadores para criação de sistemas inteligentes e automatizados. Casa inteligente, robôs autônomos, sistemas de monitoramento ambiental e soluções de automação residencial e industrial.</p>
</div>

<div class="area-card">
    <div class="area-icon">⚡</div>
    <h3>Edge Computing</h3>
    <p>Computação na borda da rede com processamento local de dados, redução de latência e aplicações em tempo real. Sistemas de reconhecimento facial local, análise de vídeo edge, monitoramento industrial e soluções IoT com processamento distribuído.</p>
</div>

<div class="area-card">
    <div class="area-icon">🏆</div>
    <h3>Projeto do Ano</h3>
    <p>Projeto integrador que consolida conhecimentos de múltiplas disciplinas, demonstrando competências técnicas e colaborativas. Sistema completo de gestão escolar com dashboard, banco de dados, autenticação e interface responsiva desenvolvido em equipe.</p>
</div>
</div>

<div style="background: linear-gradient(135deg, rgba(0, 102, 204, 0.05), rgba(0, 163, 255, 0.05)); padding: 2.5rem; border-radius: 12px; margin-top: 3rem;">
<h3 style="color: var(--dark-blue); font-size: 1.8rem; margin-bottom: 1.5rem; text-align: center;">💡 Metodologia de Desenvolvimento</h3>
<p style="color: #666; font-size: 1.05rem; line-height: 1.8; text-align: justify; margin-bottom: 1rem;">
    Todos os projetos foram desenvolvidos seguindo metodologias ágeis e boas práticas de programação, incluindo versionamento de código com Git/GitHub, documentação técnica detalhada, testes de funcionalidade e design responsivo. A abordagem sempre priorizou a resolução de problemas reais, a usabilidade e a escalabilidade das soluções.
</p>
<p style="color: #666; font-size: 1.05rem; line-height: 1.8; text-align: justify;">
    Além da programação, desenvolvi competências essenciais como trabalho em equipe, comunicação técnica,<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Home - Portfólio Theo Campos Okada</title>
<style>
* {
margin: 0;
padding: 0;
box-sizing: border-box;
}

:root {
--primary-blue: #0066cc;
--dark-blue: #003d7a;
--light-blue: #4d94ff;
--accent-blue: #00a3ff;
--bg-dark: #0a1628;
--bg-light: #f0f4f8;
--text-dark: #1a1a1a;
--text-light: #ffffff;
}

body {
font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
line-height: 1.6;
color: var(--text-dark);
overflow-x: hidden;
background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%);
min-height: 100vh;
}

/* Navigation */
nav {
position: fixed;
top: 0;
width: 100%;
background: linear-gradient(135deg, var(--dark-blue), var(--primary-blue));
padding: 1rem 2rem;
z-index: 1000;
box-shadow: 0 4px 20px rgba(0, 102, 204, 0.3);
}

nav ul {
list-style: none;
display: flex;
flex-wrap: wrap;
justify-content: center;
gap: 1.5rem;
}

nav a {
color: var(--text-light);
text-decoration: none;
font-weight: 600;
transition: all 0.3s ease;
position: relative;
padding: 0.5rem 1rem;
}

nav a:hover,
nav a.active {
color: var(--accent-blue);
}

nav a::after {
content: '';
position: absolute;
bottom: 0;
left: 50%;
width: 0;
height: 2px;
background: var(--accent-blue);
transition: all 0.3s ease;
transform: translateX(-50%);
}

nav a:hover::after,
nav a.active::after {
width: 100%;
}

/* Geometric Background */
.geometric-bg {
position: fixed;
top: 0;
left: 0;
width: 100%;
height: 100%;
overflow: hidden;
z-index: -1;
}

.geometric-shape {
position: absolute;
opacity: 0.1;
animation: float 20s infinite ease-in-out;
}

.shape-1 {
width: 300px;
height: 300px;
border: 3px solid var(--primary-blue);
top: 10%;
left: 5%;
transform: rotate(45deg);
animation-delay: 0s;
}

.shape-2 {
width: 200px;
height: 200px;
border: 3px solid var(--accent-blue);
bottom: 20%;
right: 10%;
transform: rotate(30deg);
animation-delay: 5s;
}

.shape-3 {
width: 150px;
height: 150px;
background: linear-gradient(135deg, var(--light-blue), var(--primary-blue));
top: 50%;
right: 5%;
clip-path: polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%);
animation-delay: 10s;
}

.shape-4 {
width: 100px;
height: 100px;
border: 3px solid var(--primary-blue);
top: 30%;
right: 20%;
clip-path: polygon(30% 0%, 70% 0%, 100% 30%, 100% 70%, 70% 100%, 30% 100%, 0% 70%, 0% 30%);
animation-delay: 7s;
}

@keyframes float {
0%, 100% { transform: translateY(0) rotate(45deg); }
50% { transform: translateY(-50px) rotate(225deg); }
}

/* Main Container */
.container {
max-width: 1200px;
margin: 0 auto;
padding: 100px 2rem 2rem;
min-height: 100vh;
}

/* Section Tabs */
.section-tabs {
display: flex;
gap: 1rem;
margin-bottom: 3rem;
flex-wrap: wrap;
justify-content: center;
background: white;
padding: 1rem;
border-radius: 12px;
box-shadow: 0 4px 20px rgba(0, 102, 204, 0.1);
}

.tab-button {
padding: 1rem 2rem;
background: var(--bg-light);
border: 2px solid var(--primary-blue);
color: var(--primary-blue);
border-radius: 8px;
cursor: pointer;
font-weight: 600;
font-size: 1.1rem;
transition: all 0.3s ease;
position: relative;
overflow: hidden;
}

.tab-button:hover {
transform: translateY(-3px);
box-shadow: 0 4px 15px rgba(0, 102, 204, 0.2);
}

.tab-button.active {
background: linear-gradient(135deg, var(--primary-blue), var(--accent-blue));
color: white;
border-color: transparent;
}

/* Tab Content */
.tab-content {
display: none;
animation: fadeIn 0.5s ease;
}

.tab-content.active {
display: block;
}

@keyframes fadeIn {
from {
opacity: 0;
transform: translateY(20px);
}
to {
opacity: 1;
transform: translateY(0);
}
}

/* Introdução Tab */
.intro-section {
display: flex;
align-items: center;
gap: 4rem;
flex-wrap: wrap;
justify-content: center;
background: white;
padding: 3rem;
border-radius: 12px;
box-shadow: 0 4px 20px rgba(0, 102, 204, 0.1);
}

.photo-section {
position: relative;
flex-shrink: 0;
}

.photo-container {
position: relative;
width: 350px;
height: 350px;
}

.photo-frame {
width: 100%;
height: 100%;
border: 5px solid var(--primary-blue);
position: relative;
overflow: hidden;
clip-path: polygon(20% 0%, 100% 0%, 80% 100%, 0% 100%);
background: white;
display: flex;
align-items: center;
justify-content: center;
box-shadow: 0 10px 40px rgba(0, 102, 204, 0.3);
transition: all 0.3s ease;
}

.photo-frame:hover {
transform: translateY(-10px);
box-shadow: 0 15px 50px rgba(0, 102, 204, 0.4);
}

.photo-frame img {
width: 100%;
height: 100%;
object-fit: cover;
}

.photo-placeholder {
font-size: 1.2rem;
color: var(--primary-blue);
text-align: center;
padding: 2rem;
}

.photo-placeholder svg {
width: 80px;
height: 80px;
margin-bottom: 1rem;
}

.photo-decoration {
position: absolute;
border: 2px solid var(--accent-blue);
opacity: 0.3;
}

.deco-1 {
width: 80px;
height: 80px;
top: -20px;
right: -20px;
clip-path: polygon(100% 0, 0 0, 100% 100%);
}

.deco-2 {
width: 60px;
height: 60px;
bottom: -15px;
left: -15px;
transform: rotate(45deg);
}

.text-section {
flex: 1;
min-width: 300px;
max-width: 600px;
}

h1 {
font-size: 3.5rem;
margin-bottom: 1rem;
background: linear-gradient(135deg, var(--primary-blue), var(--accent-blue));
-webkit-background-clip: text;
-webkit-text-fill-color: transparent;
background-clip: text;
line-height: 1.2;
}

.subtitle {
font-size: 1.5rem;
color: var(--dark-blue);
margin-bottom: 2rem;
font-weight: 500;
}

.intro-text {
font-size: 1.1rem;
line-height: 1.8;
margin-bottom: 1.5rem;
color: var(--text-dark);
text-align: justify;
}

/* Descrição Tab */
.description-section {
background: white;
padding: 3rem;
border-radius: 12px;
box-shadow: 0 4px 20px rgba(0, 102, 204, 0.1);
}

.description-section h2 {
color: var(--dark-blue);
font-size: 2.5rem;
margin-bottom: 2rem;
text-align: center;
}

.areas-grid {
display: grid;
grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
gap: 2rem;
margin-top: 2rem;
}

.area-card {
background: var(--bg-light);
padding: 2rem;
border-radius: 12px;
border-left: 4px solid var(--primary-blue);
transition: all 0.3s ease;
}

.area-card:hover {
transform: translateX(10px);
background: white;
box-shadow: 0 4px 20px rgba(0, 102, 204, 0.15);
}

.area-icon {
font-size: 2.5rem;
margin-bottom: 1rem;
}

.area-card h3 {
color: var(--dark-blue);
margin-bottom: 1rem;
font-size: 1.3rem;
}

.area-card p {
color: #666;
line-height: 1.7;
}

.stats-section {
margin-top: 3rem;
display: grid;
grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
gap: 1.5rem;
}

.stat-card {
background: rgba(255, 255, 255, 0.9);
padding: 1.5rem;
border-radius: 8px;
text-align: center;
box-shadow: 0 4px 15px rgba(0, 102, 204, 0.1);
transition: all 0.3s ease;
}

.stat-card:hover {
transform: translateY(-5px);
box-shadow: 0 6px 20px rgba(0, 102, 204, 0.2);
}

.stat-number {
font-size: 2.5rem;
font-weight: bold;
color: var(--primary-blue);
margin-bottom: 0.5rem;
}

.stat-label {
font-size: 0.9rem;
color: var(--text-dark);
font-weight: 500;
}

/* Projetos Tab */
.projects-section {
background: white;
padding: 3rem;
border-radius: 12px;
box-shadow: 0 4px 20px rgba(0, 102, 204, 0.1);
}

.projects-section h2 {
color: var(--dark-blue);
font-size: 2.5rem;
margin-bottom: 2rem;
text-align: center;
}

.projects-grid {
display: grid;
grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
gap: 2rem;
margin-top: 2rem;
}

.project-card {
background: var(--bg-light);
border-radius: 12px;
overflow: hidden;
box-shadow: 0 4px 20px rgba(0, 102, 204, 0.1);
transition: all 0.3s ease;
position: relative;
}

.project-card::before {
content: '';
position: absolute;
top: 0;
left: 0;
width: 100%;
height: 4px;
background: linear-gradient(90deg, var(--primary-blue), var(--accent-blue));
}

.project-card:hover {
transform: translateY(-10px);
box-shadow: 0 8px 30px rgba(0, 102, 204, 0.2);
}

.project-image {
width: 100%;
height: 200px;
background: linear-gradient(135deg, var(--light-blue), var(--primary-blue));
display: flex;
align-items: center;
justify-content: center;
color: white;
font-size: 3rem;
}

.project-content {
padding: 1.5rem;
background: white;
}

.project-content h3 {
color: var(--dark-blue);
margin-bottom: 1rem;
}

.project-content p {
margin-bottom: 1rem;
color: #666;
}

.project-link {
display: inline-block;
padding: 0.5rem 1.5rem;
background: var(--primary-blue);
color: white;
text-decoration: none;
border-radius: 4px;
transition: all 0.3s ease;
}

.project-link:hover {
background: var(--dark-blue);
transform: scale(1.05);
}

/* CTA Buttons */
.cta-buttons {
display: flex;
gap: 1rem;
margin-top: 2rem;
flex-wrap: wrap;
}

.btn {
padding: 1rem 2rem;
text-decoration: none;
border-radius: 8px;
font-weight: 600;
font-size: 1.1rem;
transition: all 0.3s ease;
display: inline-flex;
align-items: center;
gap: 0.5rem;
position: relative;
overflow: hidden;
}

.btn-primary {
background: linear-gradient(135deg, var(--primary-blue), var(--accent-blue));
color: white;
box-shadow: 0 4px 15px rgba(0, 102, 204, 0.3);
}

.btn-primary:hover {
transform: translateY(-3px);
box-shadow: 0 6px 20px rgba(0, 102, 204, 0.4);
}

.btn-secondary {
background: white;
color: var(--primary-blue);
border: 2px solid var(--primary-blue);
}

.btn-secondary:hover {
background: var(--primary-blue);
color: white;
transform: translateY(-3px);
}

/* Responsive */
@media (max-width: 1024px) {
.intro-section {
gap: 3rem;
}

.photo-container {
width: 300px;
height: 300px;
}

h1 {
font-size: 2.8rem;
}

.subtitle {
font-size: 1.3rem;
}
}

@media (max-width: 768px) {
nav ul {
gap: 0.5rem;
}

nav a {
padding: 0.3rem 0.6rem;
font-size: 0.9rem;
}

.container {
padding: 80px 1rem 2rem;
}

.intro-section {
flex-direction: column;
padding: 2rem;
}

.photo-container {
width: 250px;
height: 250px;
}

h1 {
font-size: 2.2rem;
text-align: center;
}

.subtitle {
font-size: 1.1rem;
text-align: center;
}

.intro-text {
text-align: left;
font-size: 1rem;
}

.cta-buttons {
justify-content: center;
}

.btn {
padding: 0.8rem 1.5rem;
font-size: 1rem;
}

.stats-section {
grid-template-columns: repeat(2, 1fr);
}

.tab-button {
padding: 0.8rem 1.5rem;
font-size: 1rem;
}

.section-tabs {
padding: 0.5rem;
}

.description-section,
.projects-section {
padding: 2rem;
}

.projects-grid {
grid-template-columns: 1fr;
}

.areas-grid {
grid-template-columns: 1fr;
}
}

@media (max-width: 480px) {
h1 {
font-size: 1.8rem;
}

.subtitle {
font-size: 1rem;
}

.photo-container {
width: 200px;
height: 200px;
}

.stats-section {
grid-template-columns: 1fr;
}
}
</style>
</head>
<body>
<!-- Navigation -->
<nav>
<ul>
<li><a href="index.php">Home</a></li>
            <li><a href="Habilidades.html">Habilidades</a></li>
            <li><a href="Linguagens.html">Linguagens</a></li>
            <li><a href="PA.html">Projeto do Ano</a></li>
            <li><a href="CH.html">Ciências Humanas</a></li>
            <li><a href="CN.html">Ciências da Natureza</a></li>
            <li><a href="Cibersegurança.html">Cibersegurança</a></li>
            <li><a href="blockchain.html">Blockchain</a></li>
            <li><a href="Automação.html">Automação</a></li>
            <li><a href="Edgecomputing.html">Edge Computing</a></li>
            <li><a href="Contato.html">Contato</a></li>
</ul>
</nav>

<!-- Geometric Background -->
<div class="geometric-bg">
<div class="geometric-shape shape-1"></div>
<div class="geometric-shape shape-2"></div>
<div class="geometric-shape shape-3"></div>
<div class="geometric-shape shape-4"></div>
</div>

<!-- Main Container -->
<div class="container">
<!-- Section Tabs -->
<div class="section-tabs">
<button class="tab-button active" data-tab="introducao">📋 Introdução</button>
<button class="tab-button" data-tab="descricao">📝 Descrição</button>
<button class="tab-button" data-tab="projetos">💼 Projetos</button>
</div>

<!-- Introdução Tab -->
<div class="tab-content active" id="introducao">
<div class="intro-section">
<div class="photo-section">
<div class="photo-container">
<div class="photo-frame">
        <img src="Imagens da Silva/1759849043104.png" alt="Theo Campos Okada">
    </div>
    <div class="photo-decoration deco-1"></div>
    <div class="photo-decoration deco-2"></div>
</div>
</div>

<div class="text-section">
<h1>Theo Campos Okada</h1>
<p class="subtitle">Estudante de T.I. | Desenvolvedor | Entusiasta de Tecnologia</p>

<p class="intro-text">
    Bem-vindo ao meu portfólio digital! Sou estudante do Ensino Médio com grande paixão por tecnologia da informação e inovação. Durante minha jornada acadêmica nos últimos três anos, desenvolvi conhecimentos sólidos em diversas áreas da computação.
</p>

<p class="intro-text">
    Este espaço foi criado para apresentar meus principais projetos e competências desenvolvidas ao longo do curso, abrangendo desde fundamentos de programação até tecnologias emergentes como blockchain, cibersegurança, automação e edge computing.
</p>

<div class="cta-buttons">
    <a href="habilidades.html" class="btn btn-primary">
        Ver Habilidades →
    </a>
    <a href="contato.html" class="btn btn-secondary">
        Entre em Contato
    </a>
</div>

<div class="stats-section">
    <div class="stat-card">
        <div class="stat-number">3</div>
        <div class="stat-label">Anos de Estudo</div>
    </div>
    <div class="stat-card">
        <div class="stat-number">10+</div>
        <div class="stat-label">Projetos</div>
    </div>
    <div class="stat-card">
        <div class="stat-number">9</div>
        <div class="stat-label">Áreas Exploradas</div>
    </div>
    <div class="stat-card">
        <div class="stat-number">100%</div>
        <div class="stat-label">Dedicação</div>
    </div>
</div>
</div>
</div>
</div>

<!-- Descrição Tab -->
<div class="tab-content" id="descricao">
<div class="description-section">
<h2>📖 Sobre o Portfólio</h2>
<div style="background: white; padding: 2rem; border-radius: 12px; box-shadow: 0 4px 20px rgba(0, 102, 204, 0.1); margin-bottom: 3rem;">
<p style="color: #666; font-size: 1.15rem; line-height: 1.9; text-align: justify; margin-bottom: 1.5rem;">
    Este portfólio digital foi desenvolvido como parte dos requisitos de conclusão do Ensino Médio técnico em Tecnologia da Informação. Durante três anos de formação intensiva, tive a oportunidade de explorar diferentes vertentes da computação e tecnologia, desde os fundamentos de programação até tecnologias emergentes que estão moldando o futuro da sociedade digital.
</p>
<p style="color: #666; font-size: 1.15rem; line-height: 1.9; text-align: justify; margin-bottom: 1.5rem;">
    O objetivo deste espaço é documentar e apresentar minha evolução técnica e acadêmica, consolidando em um só lugar os principais projetos, competências e aprendizados adquiridos. Cada seção representa uma área específica do conhecimento em que mergulhei profundamente, sempre buscando a integração entre teoria e prática, entre o conhecimento tradicional e a inovação tecnológica.
</p>
<p style="color: #666; font-size: 1.15rem; line-height: 1.9; text-align: justify;">
    Mais do que uma simples coleção de trabalhos, este portfólio reflete minha jornada de aprendizado contínuo, os desafios superados, as colaborações estabelecidas e a paixão crescente pela tecnologia como ferramenta de transformação social. Cada projeto aqui apresentado representa horas de estudo, experimentação, erros, acertos e, principalmente, o desenvolvimento de um mindset voltado para a resolução de problemas reais através da programação e da criatividade.
</p>
</div>

<h2 style="color: var(--dark-blue); font-size: 2.2rem; margin-bottom: 2rem; text-align: center;">🎯 Áreas de Conhecimento Exploradas</h2>
<p style="text-align: center; color: #666; font-size: 1.1rem; margin-bottom: 3rem;">
Durante os três anos do Ensino Médio, desenvolvi projetos e competências em diversas áreas do conhecimento, integrando tecnologia com disciplinas tradicionais e explorando as fronteiras da inovação digital.
</p>

<div class="areas-grid">
<div class="area-card">
    <div class="area-icon">📚</div>
    <h3>Linguagens</h3>
    <p>Projetos envolvendo produção textual, análise literária, comunicação digital e expressão artística com uso de tecnologias web e multimídia.</p>
</div>

<div class="area-card">
    <div class="area-icon">🌍</div>
    <h3>Ciências Humanas</h3>
    <p>Integração de História, Geografia, Sociologia e Filosofia com T.I., desenvolvendo mapas interativos, análises de dados sociais e plataformas educativas.</p>
</div>

<div class="area-card">
    <div class="area-icon">🔬</div>
    <h3>Ciências da Natureza</h3>
    <p>Aplicações de Física, Química, Biologia e Matemática através de simuladores, calculadoras científicas e sistemas de análise de dados.</p>
</div>

<div class="area-card">
    <div class="area-icon">🔒</div>
    <h3>Cibersegurança</h3>
    <p>Estudos em segurança da informação, criptografia, autenticação, detecção de vulnerabilidades e proteção de sistemas e dados.</p>
</div>

<div class="area-card">
    <div class="area-icon">⛓️</div>
    <h3>Blockchain</h3>
    <p>Exploração de tecnologia blockchain, criptomoedas, contratos inteligentes e aplicações descentralizadas com implementações práticas.</p>
</div>

<div class="area-card">
    <div class="area-icon">🤖</div>
    <h3>Automação e Robótica</h3>
    <p>Projetos com Arduino, Raspberry Pi, IoT, sensores e atuadores para criação de sistemas inteligentes e automatizados.</p>
</div>

<div class="area-card">
    <div class="area-icon">⚡</div>
    <h3>Edge Computing</h3>
    <p>Computação na borda da rede com processamento local de dados, redução de latência e aplicações em tempo real.</p>
</div>

<div class="area-card">
    <div class="area-icon">🏆</div>
    <h3>Projeto do Ano</h3>
    <p>Projeto integrador que consolida conhecimentos de múltiplas disciplinas, demonstrando competências técnicas e colaborativas.</p>
</div>
</div>
</div>
</div>

<!-- Projetos Tab -->
<div class="tab-content" id="projetos">
<div class="projects-section">
<h2>💼 Projetos em Destaque</h2>
<p style="text-align: center; color: #666; font-size: 1.1rem; margin-bottom: 2rem;">
Seleção dos principais projetos desenvolvidos ao longo do curso, demonstrando aplicação prática de conhecimentos em tecnologia.
</p>

<div class="projects-grid">
<div class="project-card">
    <div class="project-image">🚀</div>
    <div class="project-content">
        <h3>Sistema de Gestão Escolar</h3>
        <p>Plataforma web completa para gerenciamento acadêmico com dashboard, notas, frequência e comunicação interna.</p>
        <a href="PA.html" class="project-link">Ver Detalhes</a>
    </div>
</div>

<div class="project-card">
    <div class="project-image">🔐</div>
    <div class="project-content">
        <h3>Sistema de Autenticação Segura</h3>
        <p>Implementação de login com hash, 2FA, JWT e proteção contra ataques de força bruta.</p>
        <a href="Cibersegurança.html" class="project-link">Ver Detalhes</a>
    </div>
</div>

<div class="project-card">
    <div class="project-image">⛓️</div>
    <div class="project-content">
        <h3>Blockchain Educacional</h3>
        <p>Implementação de blockchain básica em Python com transações, mining e explorador de blocos.</p>
        <a href="blockchain.html" class="project-link">Ver Detalhes</a>
    </div>
</div>

<div class="project-card">
    <div class="project-image">🏠</div>
    <div class="project-content">
        <h3>Casa Inteligente IoT</h3>
        <p>Sistema de automação residencial com Arduino, sensores e controle via aplicativo web.</p>
        <a href="Automação.html" class="project-link">Ver Detalhes</a>
    </div>
</div>

<div class="project-card">
    <div class="project-image">📹</div>
    <div class="project-content">
        <h3>Reconhecimento Facial Edge</h3>
        <p>Sistema de reconhecimento facial processado localmente em Raspberry Pi para controle de acesso.</p>
        <a href="Edgecomputing.html" class="project-link">Ver Detalhes</a>
    </div>
</div>

<div class="project-card">
    <div class="project-image">📍</div>
    <div class="project-content">
        <h3>Mapeamento Histórico Digital</h3>
        <p>Aplicação web interativa com geolocalização e timeline de eventos históricos do Brasil.</p>
        <a href="CH.html" class="project-link">Ver Detalhes</a>
    </div>
</div>

<div class="project-card">
    <div class="project-image">⚗️</div>
    <div class="project-content">
        <h3>Simulador de Reações Químicas</h3>
        <p>Aplicação interativa para visualização de reações com cálculos estequiométricos automatizados.</p>
        <a href="CN.html" class="project-link">Ver Detalhes</a>
    </div>
</div>

<div class="project-card">
    <div class="project-image">📚</div>
    <div class="project-content">
        <h3>Blog Literário Digital</h3>
        <p>Blog responsivo para publicação de resenhas literárias e análises de obras clássicas.</p>
        <a href="Linguagens.html" class="project-link">Ver Detalhes</a>
    </div>
</div>

<div class="project-card">
    <div class="project-image">🤖</div>
    <div class="project-content">
        <h3>Robô Seguidor de Linha</h3>
        <p>Robô autônomo com sensores infravermelhos e algoritmo PID para controle preciso.</p>
        <a href="automacao.html" class="project-link">Ver Detalhes</a>
    </div>
</div>
</div>

<div style="text-align: center; margin-top: 3rem;">
<a href="Habilidades.html" class="btn btn-primary">
    Ver Todos os Projetos →
</a>
</div>
</div>
</div>
</div>

<script>
// Tab functionality
const tabButtons = document.querySelectorAll('.tab-button');
const tabContents = document.querySelectorAll('.tab-content');

tabButtons.forEach(button => {
button.addEventListener('click', () => {
// Remove active class from all buttons and contents
tabButtons.forEach(btn => btn.classList.remove('active'));
tabContents.forEach(content => content.classList.remove('active'));

// Add active class to clicked button and corresponding content
button.classList.add('active');
const tabId = button.getAttribute('data-tab');
document.getElementById(tabId).classList.add('active');
});
});

// Smooth animations on scroll
const observerOptions = {
threshold: 0.1,
rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
entries.forEach(entry => {
if (entry.isIntersecting) {
entry.target.style.opacity = '1';
entry.target.style.transform = 'translateY(0)';
}
});
}, observerOptions);

// Observe cards
document.querySelectorAll('.project-card, .area-card, .stat-card').forEach(card => {
card.style.opacity = '0';
card.style.transform = 'translateY(20px)';
card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
observer.observe(card);
});
</script>
</body>
</html>