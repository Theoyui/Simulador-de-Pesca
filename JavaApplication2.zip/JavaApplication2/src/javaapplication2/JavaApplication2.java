/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication2;

import javax.swing.JOptionPane;

/**
 *
 * @author theo.cokada
 */
public class JavaApplication2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int login = 0;
        int cadastro = 0;
        JOptionPane.showConfirmDialog(null,"Deseja fazer Login?");
         if (login == JOptionPane.YES_OPTION) {
             
        }
         else {
        JOptionPane.showConfirmDialog(null,"Deseja fazer Cadastro?");
        
        }
        
        JOptionPane.showMessageDialog(null,"Você é baiano?");
        String usuário = JOptionPane.showInputDialog("Qual o seu nome");
      
           
    }
    
}
