/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;
import javax.swing.JOptionPane;

/**
 *
 * @author theo.cokada
 */
public class JavaApplication2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        // TODO code application logic here
 
        
        int loop = 0;
       
         JOptionPane.showMessageDialog(null,"Realize seu cadastro");
         String usuario = JOptionPane.showInputDialog("Usuário");
         String senha = JOptionPane.showInputDialog("Senha");
         JOptionPane.showMessageDialog(null,"Seu cadastro foi realizado com sucesso");
        
         int login = JOptionPane.showConfirmDialog(null,"Deseja logar na sua conta?");
        
        if(login == JOptionPane.NO_OPTION) {
        JOptionPane.showMessageDialog(null,"Fechando aplicativo");
        System.exit(0);
         
         }
       
        else if(login == JOptionPane.YES_OPTION) {
         while (loop == 0) {
         String usuario1 = JOptionPane.showInputDialog("Usuário");
         String senha1 = JOptionPane.showInputDialog("Senha");
             if (usuario1.equals(usuario)) {
                 if (senha1.equals(senha)) {
                     JOptionPane.showMessageDialog(null,"Seu login foi realizado com sucesso");
                     String nome = JOptionPane.showInputDialog("Insira seu nome");
                     String cpf = JOptionPane.showInputDialog("Insira seu CPF");
                     
                     System.out.println("Seu nome é "+ nome);
                     System.out.println("Seu CPF é "+ cpf);
                     break;
                     
                 }
                 else {
                     int tente = JOptionPane.showConfirmDialog(null,"Algo está errado com seu login, deseja tentar novamente?");
                     if (tente == JOptionPane.YES_OPTION) {
                         
                     }
                     else if (tente == JOptionPane.NO_OPTION) {
                     break;
                     }
                     else if (tente == JOptionPane.CANCEL_OPTION) {
                     break;
                     }
                 }   
             }
             else {
                 int tente1 = JOptionPane.showConfirmDialog(null,"Algo está errado com seu login, deseja tentar novamente?");
                     if (tente1 == JOptionPane.YES_OPTION) {
                         
                     }
                     else if (tente1 == JOptionPane.NO_OPTION) {
                     break;
                     }
                     else if (tente1 == JOptionPane.CANCEL_OPTION) {
                     break;
             }
        }
        
         if(login == JOptionPane.CANCEL_OPTION) {
         JOptionPane.showMessageDialog(null,"Fechando aplicativo");
         System.exit(0);
       
    }
    
    }
    }
    }
}
